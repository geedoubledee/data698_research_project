# -*- coding: utf-8 -*-
"""
Created on Thu Feb 29 11:57:39 2024

@author: glend
"""

import asyncio
if asyncio.get_event_loop().is_running():
    import nest_asyncio
    nest_asyncio.apply()
import numpy as np
from os.path import exists
import pandas as pd
from requests_html import AsyncHTMLSession
from timeit import default_timer as timer

# Retrieve Web site html, including rendered javascript
async def get_web_site(url):
    asession = AsyncHTMLSession()
    r = await asession.get(url)
    await r.html.arender(sleep = 10)
    html = r.html
    await asession.close()
    return html

# Extra key info from the html
def extract_info(html):
    while True: 
        row = {}
        # Recipe name
        row["Recipe_Name"] = html.find("#article-header--recipe_1-0",
                                       first=True).find("h1", first=True).text
        # Basic info
        basic_info_grid = html.find("#article-content_1-0", first=True)
        basic_info_labels = basic_info_grid.find(".mntl-recipe-details__label")
        basic_info_values = basic_info_grid.find(".mntl-recipe-details__value")
        basic_info_dict = dict(zip(basic_info_labels, basic_info_values))
        basic_info = []
        for k, v in basic_info_dict.items():
            txt = " ".join([k.text, v.text])
            basic_info.append(txt)
        row["Basic_Info"] = basic_info
        # Ingredients list
        ing_elem_list = html.find(".mntl-structured-ingredients__list-item")
        ingredients = []
        for ing in ing_elem_list:
            ingredients.append(ing.text)
        row["Ingredients"] = ingredients
        # Directions list
        direct_elem_list = html.find("#recipe__steps-content_1-0",
                                     first=True).find("p")
        directions = []
        for direct in direct_elem_list:
            directions.append(direct.text)
        row["Directions"] = directions
        # Nutrition
        nutr_tbl_rows = html.find(".mntl-nutrition-facts-summary__table",
                                  first=True).find("tr")
        nutrition = []
        for tbl_row in nutr_tbl_rows:
            cells = tbl_row.find("td")
            txt = []
            for cell in cells:
                txt.append(cell.text)
            nutrition.append(" ".join(txt))
        row["Nutrition"] = nutrition
        try:
            # Total number of ratings:
            row["Ratings_Total"] = int(html.find(".ratings-histogram__total",
                                                 first=True).text.split(sep = " ")[0])
            # Average rating:
            row["Ratings_Avg"] = float(html.find(".ratings-histogram__average-text",
                                                 first=True).text.split(sep = " out of ")[0])
            # Total number of reviews:
            row["Reviews_Total"] = int(html.find(".feedback-list",
                                                 first=True).find("h2", first=True).text.split(sep = " (")[1][:-1])
        except:
            # Recipe has not been reviewed
            break
        try:
            # Most helpful positive review:
            mhpr_cont = html.find(".feedback__most-helpful", first=True)
            row["MHPR_User"] = mhpr_cont.find(".feedback__display-name",
                                              first=True).text
            mhpr_stars = mhpr_cont.find(".feedback__star")
            mhpr_rating = 0
            for star in mhpr_stars:
                for k, v in star.find("svg", first=True).attrs.items():
                    if v[1] == "ugc-icon-star":
                        mhpr_rating += 1
                    else:
                        continue
            row["MHPR_Rating"] = mhpr_rating
            row["MHPR_Date"] = mhpr_cont.find(".feedback__meta-date",
                                              first=True).text
            row["MHPR_Review"] = mhpr_cont.find(".feedback__text",
                                                first=True).text
            row["MHPR_Review_Len"] = len(row["MHPR_Review"])
            row["MHPR_Helpful"] = int(mhpr_cont.find(".feedback__helpful-counts",
                                                     first=True).text.split(sep = " (")[1][:-1])
        except:
            # none of the reviews have been marked helpful
            missing = ["MHPR_User", "MHPR_Rating", "MHPR_Date", "MHPR_Review",
                       "MHPR_Review_Len", "MHPR_Helpful"]
            for m in missing:
                row[m] = None
        # Newest reviews:
        review_cont = html.find(".feedback-list__items",
                                first=True).find(".feedback-list__item")
        k = []
        v = []
        for i in range(len(review_cont)):
            s = str(i)
            review = review_cont[i]
            k = k + ["User_" + s, "Rating_" + s, "Date_" + s, "Review_" + s,
                     "Review_Len" + s, "Helpful_" + s]
            stars = review.find(".feedback__star")
            rating = 0
            for star in stars:
                for val in star.find("svg", first=True).attrs.values():
                    if val[1] == "ugc-icon-star":
                        rating += 1
                    else:
                        continue
            try:
                txt = review.find(".feedback__text", first=True).text
                txt_len = len(txt)
            except:
                txt = None
                txt_len = 0
            v = v + [review.find(".feedback__display-name", first=True).text,
                     rating,
                     review.find(".feedback__meta-date", first=True).text,
                     txt,
                     txt_len,
                     int(review.find(".feedback__helpful-counts",
                                     first=True).text.split(sep = " (")[1][:-1])]
        row.update(dict(zip(k, v)))
        return row

# Get links
def get_links(html):
    all_links = sorted(html.links)
    excl = ["/about-us-", "/account/", "//flipboard.com", "//twitter.com",
               "//w1.buysub.com", "//websupport.meredith.com/", "/allstars-",
               "/how-to-submit-recipes/", "/authentication/", "/author/",
               "/cook/", "/food-news-trends/", "/kitchen-tips/", "/sweepstakes/",
               "//www.dotdashmeredith.com", "//www.esha.com", "//www.facebook.com",
               "//www.instagram.com", "//www.magazines.com", "//www.pinterest.com",
               "//www.tiktok.com", "//www.youtube.com"]
    incl = all_links.copy()
    incl = [x for x in incl if len(x) > 1]
    for i in range(len(excl)):
        incl = [x for x in incl if excl[i] not in x]
    return incl

# Build dataframes
def build_dataframes(fn1, fn2):
    try: 
        max_it = int(input("Enter the max number of links to be visited: "))
    except:
        print("Input must be an integer.")
        build_dataframes(fn1, fn2)
    start = timer()
    while max_it > 0:
        print(f"\nIterations left: {max_it}")
        max_it -= 1
        if exists(fn1) and exists(fn2):
            allrecipes_df = pd.read_csv(fn1)
            links_df = pd.read_csv(fn2)
        else:
            links = ["https://www.allrecipes.com/recipe/235153/easy-baked-chicken-thighs/"]
            links_df = pd.DataFrame(pd.Series(links), columns=["URL"])
            links_df["Visited"] = 0
            allrecipes_df = pd.DataFrame()
        try: 
            url_index = links_df[links_df["Visited"] == 0].index[0]
            url = links_df.loc[url_index, "URL"]
        except:
            # means all links have been visited
            print("All links have been visited")
            break
        try: 
            html = asyncio.run(get_web_site(url))
            links_df.at[url_index, "Visited"] = 1
            links = get_links(html)
            new_link_rows = pd.DataFrame(pd.Series(links), columns=["URL"])
            new_link_rows["Visited"] = 0
            links_df = pd.concat([links_df, new_link_rows],
                                  ignore_index=True)
            links_df.drop_duplicates(subset="URL", inplace=True)
            try:
                row = {"URL": url}
                row.update(extract_info(html))
                print(f"Extracting info for recipe: \n{url}")
                new_recipe_row = pd.DataFrame(pd.Series(row)).transpose()
                allrecipes_df = pd.concat([allrecipes_df, new_recipe_row],
                                           ignore_index=True)
                allrecipes_df.to_csv("allrecipes_df.csv", index=False)
            except:
                # means url is not a recipe
                print(f"URL does not link to a recipe, recipe is formatted atypically, or recipe has not been reviewed: \n{url}")
        except:
            # means bad url
            links_df.at[url_index, "Visited"] = -1
            print(f"Bad URL: \n{url}")
        finally: 
            links_df.to_csv("links_df.csv", index=False)
    end = timer()
    minutes = (end - start) / 60
    print(f"Time elapsed: {minutes:.2f} minutes")
    repeat = input("Keep visiting links? y/n ")
    if repeat == "y":
        print("Repeating.")
        build_dataframes(fn1, fn2)
    else:
        print("Stopped.")
    return None

fn1 = "allrecipes_df.csv"
fn2 = "links_df.csv"
build_dataframes(fn1, fn2)